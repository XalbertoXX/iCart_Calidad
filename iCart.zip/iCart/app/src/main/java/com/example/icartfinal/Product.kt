package com.example.icartfinal

data class Product(
    val nombre:String
    )
