package com.example.icartfinal



data class Category(
    val nombreCategoria:String, val productos: Array<Product>
)
